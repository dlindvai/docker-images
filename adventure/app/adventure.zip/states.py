PLAY = 'play'
QUIT = 'quit'
WIN = 'win'
LOSE = 'lose'
