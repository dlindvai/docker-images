Python Games:
- Guess the number
- Indiana Jones
