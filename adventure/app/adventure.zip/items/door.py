NORMAL = 'normal'
SOAKED = 'soaked'
BURNING = 'burning'

door = {
    'name': 'dvere',
    'description': 'Veľké masívne dubové dvere. Len tak niečo a niekto s nimi nepohne, keď sú zamknuté. A to teda sú.',
    'features': [],
    'state': NORMAL
}
