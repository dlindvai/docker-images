from .coin import coin
from .figa import figa
from .canister import canister
from .newspaper import newspaper
from .matches import matches
from .fire_extinguisher import fire_extinguisher
from .door import door

from .features import MOVABLE, USABLE
