from items.features import MOVABLE

figa = {
    'name': 'figa borova',
    'description': 'Borová figa. Čo viac k tomu dodať.',
    'features': [MOVABLE]
}
